# Full Stack Blood Management System

## Tech Stack
- React.js (Frontend)
- Node.js + Express (Backend)
- MongoDB (Database)

## Run Locally
### Client:
cd client && npm install && npm start

### Server:
cd server && npm install && node server.js

